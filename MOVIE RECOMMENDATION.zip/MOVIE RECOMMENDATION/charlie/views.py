from flask import Blueprint,render_template,request
from flask_login import login_required,current_user
import operator
import pandas as pd
from scipy import spatial
from . import db
from .models import Recom
import pickle
import requests
from collections import Counter
import itertools
import random
import json
movies=pickle.load(open('movies.pkl','rb'))
views= Blueprint('views',__name__)

@views.route('/')
def home():
    return render_template("RAJAN VANIKAAR.html")

@views.route('/rec')
@login_required
def rec():
    user=current_user
    nl=[]
    fn=[]
    for repo in user.recomm:
        # print(repo.data)
        nl.append(repo.data)
    if len(nl)==0:
        pass
    elif len(nl)==10:
        ds=Counter(nl)
        sorteds=dict(sorted(ds.items(),key=lambda x:x[1],reverse=True))
        st=dict(itertools.islice(sorteds.items(),5))
        fn=st
    elif len(nl)==20:
        snl=nl[-20::1]
        ds=Counter(nl)
        sorteds=dict(sorted(ds.items(),key=lambda x:x[1],reverse=True))
        st=dict(itertools.islice(sorteds.items(),1))
        for key in st:
            # print(key)
            fn.append(key)
        for i in range(4):
            j=i//2
            vla=random.randint(j,((j+1)*10))
            while snl[vla] in fn:
                vla=random.randint(j,((j+1)*10))
            fn.append(snl[vla])
    else:
        snl=nl[-30::1]
        ds=Counter(nl)
        sorteds=dict(sorted(ds.items(),key=lambda x:x[1],reverse=True))
        st=dict(itertools.islice(sorteds.items(),2))
        for key in st:
            # print(key)
            fn.append(key)
        for i in range(3):
            vla=random.randint(i,((i+1)*10))
            while snl[vla] in fn:
                vla=random.randint(i,((i+1)*10))
            fn.append(snl[vla])
    return render_template("tryp3.html",user=current_user,sot=fn)

@views.route('/recommend',methods=['POST','GET'])
@login_required
def predict_score():
    #searched_movie = input('Enter a movie title: ')
    if request.method== 'POST':
        searched_movie=request.form.get('searched_movie') 
    try:       
        new_movie = movies[movies['original_title'].str.contains(searched_movie)].iloc[0].to_frame().T
        print('Selected Movie: ',new_movie.original_title.values[0])
        def getNeighbors(baseMovie, K):
            distances = []
    
            for index, movie in movies.iterrows():
                if movie['new_id'] != baseMovie['new_id'].values[0]:
                    dist = Similarity(baseMovie['new_id'].values[0], movie['new_id'])
                    distances.append((movie['new_id'], dist))
    
            distances.sort(key=operator.itemgetter(1))
            neighbors = []
    
            for x in range(K):
                neighbors.append(distances[x])
            return neighbors

        K = 10
        avgRating = 0
        neighbors = getNeighbors(new_movie, K)

        print('\nRecommended Movies: \n')
        recommended_movies=[]
        recommended_movies_poster=[]
        for neighbor in neighbors:
            avgRating = avgRating+movies.iloc[neighbor[0]][3]  
            recommended_movies.append( movies.iloc[neighbor[0]][1])
            # print(neighbor[0])
            recommended_movies_poster.append(fetch_poster(movies.iloc[neighbor[0]][0]))
        for i in range(10):
            dat=recommended_movies_poster[i]
            new_reco=Recom(data=dat,user_id=current_user.id)
            db.session.add(new_reco)
            db.session.commit()
        return render_template("demotemp.html",reclist=recommended_movies,user=current_user,recpost=recommended_movies_poster)
    except:
        return render_template("RAJAN VANIKAAR.html")


def Similarity(movieId1, movieId2):
    a = movies.iloc[movieId1]
    b = movies.iloc[movieId2]
    
    genresA = a['genres_bin']
    genresB = b['genres_bin']
    
    genreDistance = spatial.distance.cosine(genresA, genresB)
    
    scoreA = a['cast_bin']
    scoreB = b['cast_bin']
    scoreDistance = spatial.distance.cosine(scoreA, scoreB)
    
    directA = a['director_bin']
    directB = b['director_bin']
    directDistance = spatial.distance.cosine(directA, directB)
    
    wordsA = a['words_bin']
    wordsB = b['words_bin']
    wordsDistance = spatial.distance.cosine(wordsA, wordsB)
    return genreDistance + directDistance + scoreDistance + wordsDistance


def fetch_poster(movie_id):
    respo=requests.get('https://api.themoviedb.org/3/movie/{}?api_key=9ebd7fec8bd4fc3e5a7d4c34bd661197&language=en-US'.format(movie_id))
    data=respo.json()
    return "https://image.tmdb.org/t/p/w500"+data['poster_path']
